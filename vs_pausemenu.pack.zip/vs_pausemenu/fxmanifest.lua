fx_version 'cerulean'

game 'gta5'

author 'Vision Service'

description 'Fivem Pause menu'

version '1.0.0'

lua54 "yes"

shared_script 'config.lua'

client_script 'client.lua'

server_script 'server.lua'

ui_page 'web/index.html'

files {
    'web/*'
}

escrow_ignore {
    'config.lua'
}
dependency '/assetpacks'